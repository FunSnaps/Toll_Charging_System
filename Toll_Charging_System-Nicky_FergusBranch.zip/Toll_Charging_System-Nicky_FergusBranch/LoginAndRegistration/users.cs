﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoginAndRegistration
{
    class users
    {
        public string Name { get; set; }
        public bool Paid { get; set; }
        public string Car { get; set; }
        public string NumberPlate { get; set; }
    }
}
